        <div class="clearfix"></div>
	</div> 
    <!-- fin contenedor -->
	<!-- pie de pagina -->
    <footer >
    	<div class="text-center">
            <div class="container">
                <section>
                	<!-- Facebook -->
                    <a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.facebook.com/SICAPconsultoriainformatica" role="button" data-mdb-ripple-color="dark" target="blank">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <!-- Instagram -->
                    <a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.instagram.com/itsicapconsultoriaysistemas/?hl=es" role="button" data-mdb-ripple-color="dark" target="blank">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                    <!-- Linkedin -->
                    <a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://es.linkedin.com/company/itsicap" role="button" data-mdb-ripple-color="dark" target="blank">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <div class="text-center">
                        © <?php echo date("Y"); ?> Copyright: <a class="text-dark" href="https://itsicap.com/" target="blank" id="web">Itsicap.com</a>
                    </div>
                </section>
            </div>
        </div>
    </footer>
    <!-- fin pie de pagina -->
</body>
</html>