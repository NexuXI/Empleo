<?php
// Conexión
$servidor = 'localhost';
$usuario = 'itsicape_worksicap';
$password = '#2¡3YnHnQn?B9]4';
$basededatos = 'itsicape_worksicap';
$db = mysqli_connect($servidor, $usuario, $password, $basededatos);

mysqli_query($db, "SET NAMES 'utf8'");

// Iniciar la sesión
if(!isset($_SESSION)){
	session_start();
}