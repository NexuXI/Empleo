<?php
require_once 'includes/cabecera2.php';

$id;
$nombre;
$descripcion;
$requisitos;
$salario;
$estadoOferta;
$comunidad;
$img;
$ciudad;

if(isset($_POST)){
    $oferta = $_POST['id'];
    $nombre = isset($_POST['nombre']) ? mysqli_real_escape_string($db, $_POST['nombre']) : false;
    $descripcion = isset($_POST['descripcion']) ? mysqli_real_escape_string($db, $_POST['descripcion']) : false;
    $img = $_FILES['img']['name'];

    if(isset($_POST['nombre'])){
        $nombre_valido = true;
    }else{
        $nombre = null;
    }
    if(isset($_POST['descripcion'])){
        $descripcion = $_POST['descripcion'];
    }else{
        $descripcion = null;
    }
    if(isset($_POST['salario']) ){
        $salario = $_POST['salario'];
    }else{
        $salario = null;
    }
    if(isset($_POST['requisitos']) ){
        $requisitos = $_POST['requisitos'];
    }else{
        $requisitos = null;
    }
    if(isset($_POST['estadoOferta'])){
        $estadoOferta = $_POST['estadoOferta'];
    }else{
        $estadoOferta = "Abierta";
    }
    if(isset($_POST['comunidad'])){
        $comunidad = $_POST['comunidad'];
    }else{
        $comunidad = null;
    }
    if(isset($_POST['ciudad']) ){
        $ciudad = $_POST['ciudad'];
    }else{
        $ciudad = null;
    }
    $idEmpresa = $_SESSION['usuario']['id'];
    $sql = "SELECT * from Empresa where id ='$idEmpresa';";
    $search = mysqli_query($db, $sql);
    if(!empty($search)){
        while($ofertaCreada = mysqli_fetch_assoc($search)){
            $oCreadas = $ofertaCreada['ofertasCreadas'];
        }
    }
    if($oCreadas == 0){
        if( isset($img) && $img != "" ){
            $target_dir = "assets/ofertasIcon/"; //directorio en el que se subira
            $target_file = $target_dir . basename($_FILES["img"]["name"]);//se añade el directorio y el nombre del archivo
            $uploadOk = 1;//se añade un valor determinado en 1
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            // Comprueba si el archivo de imagen es una imagen real o una imagen falsa

            $check = getimagesize($_FILES["img"]["tmp_name"]);
            if($check !== false) {//si es falso es una imagen y si no lanza error
                echo "Archivo es una imagen- " . $check["mime"] . ". <br>";
                $uploadOk = 1;
            } else {
                echo "El archivo no es una imagen<br>";
                $uploadOk = 0;
            }
            // Comprobar si el archivo ya existe
            if (file_exists($target_file)) {
                echo "El archivo ya existe<br>";
            }
            // Comprueba el peso
            if ($_FILES["img"]["size"] > 800000) {
                echo "Perdon pero el archivo es muy pesado<br>";
                $uploadOk = 0;
            }
            // Permitir ciertos formatos de archivo
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Perdon solo, JPG, JPEG, PNG & GIF Estan soportados<br>";
                $uploadOk = 0;
            }
            //Comprueba si $ uploadOk se establece en 0 por un error
            if ($uploadOk == 0) {
                echo "Perdon, pero el archivo no se subio<br>";
                // si todo está bien, intenta subir el archivo
            } else {
                $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $ext = pathinfo($img, PATHINFO_EXTENSION);
                $newName = substr(str_shuffle($permitted_chars), 0, 20) .".".$ext;
                if (move_uploaded_file($_FILES["img"]["tmp_name"], "/home2/itsicape/public_html/worksicap.com/assets/ofertasIcon/" . $newName)) {
                    echo "El archivo ". $newName . " Se subio correctamente<br>";
                } else {
                    echo "Error al cargar el archivo<br>";
                }
                    $sql1 = "INSERT INTO OfertasEmpleo VALUES(null, '$newName', '$nombre', '$descripcion', '$requisitos', '$salario', 'Abierta','$comunidad', '$ciudad', '$idEmpresa', curdate());";
                }

        }else{
            $sql1 =  "INSERT INTO OfertasEmpleo VALUES(null, 'default.png', '$nombre', '$descripcion', '$requisitos', '$salario', 'Abierta','$comunidad', '$ciudad', '$idEmpresa', curdate());";
        }
        $guardar = mysqli_query($db, $sql1);
        if($guardar){
            echo "guardado bien<br>";
        }	
        $oCreadass = $oCreadas + 1;
        $sql = "UPDATE Empresa SET ofertasCreadas='$oCreadass' WHERE id = '$idEmpresa';";  
        $guardar = mysqli_query($db, $sql);
        header("Location: https://worksicap.com");
      	exit;
    }else{
        ?>
          <div style="display: flex; flex-direction:column; align-items: center; justify-content: center; background-color: rgba(135, 135, 135, 255); ">
            <h1 style="color: white;">Ya has creado una oferta de empleo, si quieres seguir creando más contacta a <a href="https://itsicap.com" target="_blank">ITSICAP</a> y suscribete a nosotros.</h1>
            <a href="https://worksicap.com/home/"><h3>Volver al home<h3></a>
          </div>
        <?php
    }
}
require_once 'includes/pie.php';