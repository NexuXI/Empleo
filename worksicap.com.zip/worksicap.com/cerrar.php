<?php
require_once 'includes/cabecera2.php';

session_start();

if(isset($_SESSION['usuario'])){
	session_destroy();
}

header("Location: https://worksicap.com");