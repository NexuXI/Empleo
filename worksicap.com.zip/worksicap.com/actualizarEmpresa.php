<?php

// Iniciar la sesión y la conexión a bd
require_once 'includes/cabecera2.php';

$usuario = $_SESSION['usuario']['id'];

$nombre;
$direccion;
$tlf;
$email = $_SESSION['usuario']['email'];

$foto = $_FILES['foto']['name'];

$nombre = isset($_POST['nombre']) ? mysqli_real_escape_string($db, $_POST['nombre']) : false;
$direccion = isset($_POST['direccion']) ? mysqli_real_escape_string($db, $_POST['direccion']) : false;

if(isset($_POST['nombre']) && !is_numeric($_POST['nombre']) && !preg_match("/[0-9]/", $_POST['nombre'])){
    $nombre_valido = true;
}else{
    $nombre = $_SESSION['usuario']['nombre'];
}
if(isset($_POST['direccion'])){
    $direccion = $_POST['direccion'];
}else{
    $direccion = $_SESSION['usuario']['direccion'];
}
if(isset($_POST['telefono'])  && filter_var($_POST['telefono'], FILTER_SANITIZE_NUMBER_INT)){
    $tlf = $_POST['telefono'];
}else{
    $tlf = $_SESSION['usuario']['tlf'];
}
if( isset($foto) && $foto != "" ){
        
  	$target_dir = "assets/empresasIcon/"; //directorio en el que se subira
    $target_file = $target_dir . basename($_FILES["foto"]["name"]);//se añade el directorio y el nombre del archivo
    $uploadOk = 1;//se añade un valor determinado en 1
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Comprueba si el archivo de imagen es una imagen real o una imagen falsa
    
    $check = getimagesize($_FILES["foto"]["tmp_name"]);
    if($check !== false) {//si es falso es una imagen y si no lanza error
        echo "Archivo es una imagen- " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "El archivo no es una imagen";
        $uploadOk = 0;
    }
    // Comprobar si el archivo ya existe
    if (file_exists($target_file)) {
        echo "El archivo ya existe";
    }
    // Comprueba el peso
    if ($_FILES["foto"]["size"] > 500000) {
        ?>
				<script type="text/javascript">
					function ShowMessage(){
						alert('La imagen subida es demasiado pesada.')
						window.location.href="https://worksicap.com/";
					}
					ShowMessage();
				</script>  
        <?php
        echo "Perdon pero el archivo es muy pesado";
        $uploadOk = 0;
    }
    // Permitir ciertos formatos de archivo
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Perdon solo, JPG, JPEG, PNG & GIF Estan soportados";
        $uploadOk = 0;
    }
    //Comprueba si $ uploadOk se establece en 0 por un error
    if ($uploadOk == 0) {
        echo "Perdon, pero el archivo no se subio";
    // si todo está bien, intenta subir el archivo
    } else {
        $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $ext = pathinfo($foto, PATHINFO_EXTENSION);
        $newName = substr(str_shuffle($permitted_chars), 0, 20) .".".$ext;
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], "/home2/itsicape/public_html/worksicap.com/assets/ofertasIcon/" . $newName)) {
            echo "El archivo ". $newName . " Se subio correctamente";
        } else {
            echo "Error al cargar el archivo";
        }
        $sql1 = "UPDATE Empresa SET "
        ."nombre = '$nombre', "
        ."direccion = '$direccion', "
        ."tlf = '$tlf', "
        ."imagen = '$newName' "
        ." WHERE id = '$usuario' ";
    }

}else{
    $sql1 = "UPDATE Empresa SET "
        ."nombre = '$nombre', "
        ."direccion = '$direccion', "
        ."tlf = '$tlf', "
        ." WHERE id = '$usuario' ";
}

    // ACTULIZAR USUARIO EN LA TABLA USUARIOS DE LA BBDD
    $guardar = mysqli_query($db, $sql1);

    if($guardar){
        $_SESSION['usuario']['nombre'] = $nombre;
        $_SESSION['usuario']['direccion'] = $direccion;
        $_SESSION['usuario']['tlf'] = $tlf;
        $_SESSION['usuario']['imagen'] = $newName;

        $_SESSION['completado'] = "Tus datos se han actualizado con éxito";
    }else{
        $_SESSION['errores']['general'] = "Fallo al guardar el actulizar tus datos!!";
    }

header('Location: https://worksicap.com/empresa/');