<?php require_once 'includes/cabecera.php'; 

    $busqueda;
    $comunidad;
    if(isset($_GET['busqueda'])){
        $busqueda = $_GET['busqueda'];
    }else{
        $busqueda = "";
    }
    if(isset($_GET['comunidad'])){
        $comunidad = $_GET['comunidad'];
    }else{
        $comunidad = "";
    }
    if(isset($_SESSION['usuario'])){
        $idUser = $_SESSION['usuario']['id'];
    }
    $ofertando = 0;

?>
		<div id="busca">
                <form id="searchbar" action="../search.php" method="GET" enctype="multipart/form-data">
                    <div class="search">
                        <input type="text" placeholder="Ej: Camarero, cocinero..." name="busqueda">
                        <div id="ciudad">
                            <img src="/assets/img/puntozona.png" id="localizacion">
                            <select name="comunidad" id="s" style="border-radius: 15px; margin-top: 0; width: 90%;">
                                <option value="">
                                    Todas
                                </option>
                                <option value="Andalucía">
                                    Andalucía
                                </option>
                                <option value="Aragón">
                                    Aragón
                                </option>
                                <option value="Islas Baleares">
                                    Islas Baleares
                                </option>
                                <option value="Canarias">
                                    Canarias
                                </option>
                                <option value="Cantabria">
                                    Cantabria
                                </option>
                                <option value="Castilla-La Mancha">
                                    Castilla-La Mancha
                                </option>
                                <option value="Castilla y León">
                                    Castilla y León
                                </option>
                                <option value="Cataluña">
                                    Cataluña
                                </option>
                                <option value="Comunidad de Madrid">
                                    Comunidad de Madrid
                                </option>
                                <option value="Comunidad Foral de Navarra">
                                    Comunidad Foral de Navarra
                                </option>
                                <option value="Comunidad Valenciana">
                                    Comunidad Valenciana
                                </option>
                                <option value="Extremadura">
                                    Extremadura
                                </option>
                                <option value="Galicia">
                                    Galicia
                                </option>
                                <option value="País Vasco">
                                    País Vasco
                                </option>
                                <option value="Principado de Asturias">
                                    Principado de Asturias
                                </option>
                                <option value="Región de Murcia">
                                    Región de Murcia
                                </option>
                                <option value="La Rioja">
                                    La Rioja
                                </option>
                                <option value="Ceuta">
                                    Ceuta
                                </option>
                                <option value="Melilla">
                                    Melilla
                                </option>
                            </select>
                        </div>
                    </div>
                    <div id="boton">
                        <button type="submit" id="buscar">Buscar</button>
                    </div>
                </form>
        </div>
        <div style="display: flex; flex-direction: column; justify-content: center; align-items: center;" id="busca2">
                <form action="../search.php" method="GET" id="formulario2">
                    <div id="sameSize">
                            <input type="text" class="row" id="busqueda" name="busqueda" placeholder="Ej: Camarero, cocinero..." style="border-radius: 15px; border: none; margin-bottom: 1ex; width: 100%;">
                            <div id="localizacion" class="row" style="width: 100%;">
                                <select id="selector" name="comunidad">
                                    <option value="">
                                    	Todas
                                	</option>
  									<option value="Andalucía">
                                        Andalucía
                                    </option>
                                    <option value="Aragón">
                                        Aragón
                                    </option>
                                    <option value="Islas Baleares">
                                        Islas Baleares
                                    </option>
                                    <option value="Canarias">
                                        Canarias
                                    </option>
                                    <option value="Cantabria">
                                        Cantabria
                                    </option>
                                    <option value="Castilla-La Mancha">
                                        Castilla-La Mancha
                                    </option>
                                    <option value="Castilla y León">
                                        Castilla y León
                                    </option>
                                    <option value="Cataluña">
                                        Cataluña
                                    </option>
                                    <option value="Comunidad de Madrid">
                                        Comunidad de Madrid
                                    </option>
                                    <option value="Comunidad Foral de Navarra">
                                        Comunidad Foral de Navarra
                                    </option>
                                    <option value="Comunidad Valenciana">
                                        Comunidad Valenciana
                                    </option>
                                    <option value="Extremadura">
                                        Extremadura
                                    </option>
                                    <option value="Galicia">
                                        Galicia
                                    </option>
                                    <option value="País Vasco">
                                        País Vasco
                                    </option>
                                    <option value="Principado de Asturias">
                                        Principado de Asturias
                                    </option>
                                    <option value="Región de Murcia">
                                        Región de Murcia
                                    </option>
                                    <option value="La Rioja">
                                        La Rioja
                                    </option>
                                    <option value="Ceuta">
                                        Ceuta
                                    </option>
                                    <option value="Melilla">
                                        Melilla
                                    </option>
                                </select>
                                <img src="/assets/img/puntozona.png" id="puntozona">
                            </div>
                    </div>
                    <button type="submit" class="row" id="buscar">Buscar</button>
                </form>
            </div>
		
<!-- CAJA PRINCIPAL -->
<div class="container" id="cont2" style="padding-top: 2ex;">
    <div>
        <div class="row">
            <div id="ofertas">
        
        <?php 
            if($busqueda != null && $busqueda != ""){
                if($comunidad != null && $comunidad != ""){
                    $sql="SELECT * FROM OfertasEmpleo where nombre like '%$busqueda%' or descripcion like '%$busqueda%' having comunidad = '$comunidad';";
                }else{
                    $sql="SELECT * FROM OfertasEmpleo where nombre like '%$busqueda%' or descripcion like '%$busqueda%';";
                }
            }else if( $comunidad != null && $comunidad != ""){
                $sql="SELECT * FROM OfertasEmpleo where comunidad = '$comunidad';";
            }else{
                $sql="SELECT * FROM OfertasEmpleo;";
            }


            $ofertas = mysqli_query($db, $sql);

            

            if($ofertas != null && $ofertas != ""){
                while($oferta = mysqli_fetch_assoc($ofertas)){
                    $ofertaid = $oferta['id'];
                    $estadoOferta = $oferta['estadoOferta'];
                    $sql = "SELECT e.id, e.nombre FROM Empresa e INNER JOIN OfertasEmpleo o ON e.id = o.idEmpresa where o.id = '$ofertaid';";

                    $empresa = mysqli_query($db, $sql);
                    $nombreE;

                    if(!empty($empresa)){
                        while($emp = mysqli_fetch_assoc($empresa)){
                            $nombreE = $emp['nombre'];
                            $idE = $emp['id'];
                        }
                    }
                ?>

                    <article style="padding: 2ex;">
                        <div id="register2" style="padding: 5ex; width: 100%; height: 100%;">
                            <div class="row" style="justify-content: center;">
                                <?php 
                                if($oferta['img'] != null && $oferta['img'] != ""){
                                
                                ?>
                                <img src="/assets/ofertasIcon/<?=$oferta['img'] ?>" style="height: 10em; width: auto; border-radius: 15px; padding-bottom: 1ex;">
                                <?php
                                    }else{ 
                                ?>
                                    <img src="/assets/ofertasIcon/default.png" style="height: 10em; width: auto; border-radius: 15px; padding-bottom: 1ex;">
                                <?php
                                }
                                ?>
                                <div>
                                    <h3 style="color: white;"><?=$nombreE?></h3>
                                    <hr style="color: white;">
                                    <h3 style="color: white;"><?=$oferta['nombre'] ?></h3>
                                    <hr style="color: white;">
                                    <h4 style="color: white;">
                                        <h6 style="color: white;"><?php echo $oferta['comunidad']; ?></h6>
                                        <h4 style="color: white;"><?php echo $oferta['ciudad']; ?></h4>
                                    </h4>
                                    <hr style="color: white;">
                                    <h5 style="color: white;"><?=$oferta['fecha'] ?></h5>
                                </div>
                                <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; padding-top: 2ex;">
                                    <?php
                                        if(isset($_SESSION['usuario'])){
                                            if(!isset($_SESSION['usuario']['apellidos'])){
                                                if($_SESSION['usuario']['id'] == $idE){
                                    ?>
                                    <div>
                                        <form action="../borrarOferta.php" method="POST">
                                            <input type="hidden" value="<?=$ofertaid  ?>" name="idOferta">
                                            <button type="submit" id="enter">Cerrar oferta</button>
                                        </form>
                                    </div>
                                    <?php 
                                                }
                                            }else{
                                                $sql = "SELECT * FROM CandidaturasCandidato WHERE idOferta = '$ofertaid' AND idCandidato = '$idUser';";
                                                $guardar = mysqli_query($db, $sql);
                                                if(isset($_SESSION['usuario'])){
                                                    if(isset($_SESSION['usuario']['apellidos'])){
                                                        if($estadoOferta == "Abierta"){
                                                            while($g = mysqli_fetch_assoc($guardar)){
                                    
                                                                if($g != "" && $g != null){
                                                                    $ofertando = 1;
                                                                    if($g['estadoCandidatura'] == "rechazado"){
                                                                        ?>
                                                                        <div>
                                                                            <h4 style="color: red;">Has sido rechazado de esta oferta.</h4>
                                                                        </div>
                                                                        <?php
                                                                    }else{
                                                                        ?>
                                                                        <div>
                                                                            <h4 style="color: green;">Ya estás postulado a esta oferta de empleo.</h4>
                                                                        </div>
                                                                        <?php
                                                                    }
                                                                }else{
                                                                    $ofertando = 0;
                                                                }
                                                            }
                                                                if($ofertando == 0){
                                        ?>
                                        <div>
                                            <form action="../suscribirse.php" method="post">
                                                <input type="hidden" name="idOferta" value="<?php echo $ofertaid; ?>">
                                                <input type="hidden" name="idUser" value="<?php echo $_SESSION['usuario']['id']; ?>">
                                                <button id="enter" type="submit">Postularse a la oferta</button>
                                            </form>
                                        </div>
                                        <?php
                                                                }
                                                        }else{
                                        ?>
                                        <div>
                                            <h4 style="color: red;">La oferta de trabajo ha sido cerrada</h4>
                                        </div>
                                        <?php
                                                    $ofertando = 0;
                                                    }
                                                    }
                                                }else{
                                                    ?>
                                                    <div>
                                                        <form action="../login.php" method="post">
                                                            <button id="enter" type="submit">Postularse a la oferta</button>
                                                        </form>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                        }
                                    ?>
                                    <br>
                                    <form action="../oferta.php" method="GET">
                                        <input type="hidden" value="<?=$ofertaid ?>" name="id">
                                        <button type="submit" id="enter">Ver oferta</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </article>
        
                <?php
                    $ofertando = 0;
                }
            }
        ?>
            </div>
        </div>
    </div>
</div> 
<?php 
    require_once 'includes/pie.php'; 
?>