<?php

// Iniciar la sesión y la conexión a bd
require_once 'includes/cabecera2.php';

$id;
$nombre;
$descripcion;
$requisitos;
$salario;
$estadoOferta;
$comunidad;
$img;
$ciudad;

$oferta = $_POST['id'];
$nombre = isset($_POST['nombre']) ? mysqli_real_escape_string($db, $_POST['nombre']) : false;
$descripcion = isset($_POST['descripcion']) ? mysqli_real_escape_string($db, $_POST['descripcion']) : false;
$img = $_FILES['img']['name'];

if(isset($_POST['nombre'])){
    $nombre_valido = true;
}else{
    $nombre = null;
}
if(isset($_POST['descripcion'])){
    $descripcion = $_POST['descripcion'];
}else{
    $descripcion = null;
}
if(isset($_POST['salario']) ){
    $salario = $_POST['salario'];
}else{
    $salario = null;
}
if(isset($_POST['requisitos']) ){
    $requisitos = $_POST['requisitos'];
}else{
    $requisitos = null;
}
if(isset($_POST['estadoOferta'])){
    $estadoOferta = $_POST['estadoOferta'];
}else{
    $estadoOferta = "Abierta";
}
if(isset($_POST['comunidad'])){
    $comunidad = $_POST['comunidad'];
}else{
    $comunidad = null;
}
if(isset($_POST['ciudad']) ){
    $ciudad = $_POST['ciudad'];
}else{
    $ciudad = null;
}
if( isset($img) && $img != "" ){
    
  	$target_dir = "assets/ofertasIcon/"; //directorio en el que se subira
    $target_file = $target_dir . basename($_FILES["img"]["name"]);//se añade el directorio y el nombre del archivo
    $uploadOk = 1;//se añade un valor determinado en 1
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Comprueba si el archivo de imagen es una imagen real o una imagen falsa
    
    $check = getimagesize($_FILES["img"]["tmp_name"]);
    if($check !== false) {//si es falso es una imagen y si no lanza error
        echo "Archivo es una imagen- " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "El archivo no es una imagen";
        $uploadOk = 0;
    }
    // Comprobar si el archivo ya existe
    if (file_exists($target_file)) {
        echo "El archivo ya existe";
    }
    // Comprueba el peso
    if ($_FILES["img"]["size"] > 500000) {
        echo "Perdon pero el archivo es muy pesado";
        $uploadOk = 0;
    }
    // Permitir ciertos formatos de archivo
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Perdon solo, JPG, JPEG, PNG & GIF Estan soportados";
        $uploadOk = 0;
    }
    //Comprueba si $ uploadOk se establece en 0 por un error
    if ($uploadOk == 0) {
        echo "Perdon, pero el archivo no se subio";
    // si todo está bien, intenta subir el archivo
    } else {
        $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $ext = pathinfo($img, PATHINFO_EXTENSION);
        $newName = substr(str_shuffle($permitted_chars), 0, 20) .".".$ext;
        if (move_uploaded_file($_FILES["img"]["tmp_name"], "/home2/itsicape/public_html/worksicap.com/assets/ofertasIcon/" . $newName)) {
            echo "El archivo ". $newName . " Se subio correctamente";
        } else {
            echo "Error al cargar el archivo";
        }
        $sql1 = "UPDATE OfertasEmpleo SET "
        . "img = '$newName', "
        ."nombre = '$nombre', "
        ."descripcion = '$descripcion', "
        ."requisitos = '$requisitos', "
        ."salario = '$salario', "
        ."estadoOferta = '$estadoOferta', "
        ."comunidad = '$comunidad' "
        ." WHERE id = '$oferta'; ";
    }

}else{
    $sql1 = "UPDATE OfertasEmpleo SET "
        ."nombre = '$nombre', "
        ."descripcion = '$descripcion', "
        ."requisitos = '$requisitos', "
        ."salario = '$salario', "
        ."estadoOferta = '$estadoOferta', "
        ."comunidad = '$comunidad' "
        ." WHERE id = '$oferta'; ";
}

    // ACTULIZAR ofertasempleo
    
    
    $guardar = mysqli_query($db, $sql1);
    echo "<br>";
	echo $sql1;

header('Location: misOfertas.php');