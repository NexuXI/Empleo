<?php

require_once 'includes/cabecera2.php';
// Conexión al PHPMailer
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

if(isset($_POST)){

    $idOferta = $_POST['idOferta'];
    $idUser = $_POST['idUser'];

    $puntos = 0;

    $sql = "SELECT * from candidatos where id='$idUser';";
    $resultados = mysqli_query($db, $sql);
    while($persona = mysqli_fetch_assoc($resultados)){
        $puntos = $persona['puntos'];
        $cv = $persona['curriculum'];
    }
    if($puntos == null || $puntos == ""){
        $puntos = 0;
    }
    
    if($cv != null && $cv != ""){

        $sql = "INSERT INTO CandidaturasCandidato values (null, $idUser, $idOferta, 'inscrito', curdate(), $puntos);";
        $guardar = mysqli_query($db, $sql);
    
        if($guardar == true){
        
    
        $sql = "SELECT * from OfertasEmpleo where id='$idOferta';";
        $resultados = mysqli_query($db, $sql);
        while($oferta = mysqli_fetch_assoc($resultados)){
            $idEmpres = $oferta['idEmpresa'];
            $TituloOferta = $oferta['nombre'];
        }
        $sql = "SELECT * from Empresa where id = '$idEmpres'; ";
        $resultados = mysqli_query($db, $sql);
        while($empresa = mysqli_fetch_assoc($resultados)){
            $email = $empresa['email'];
        }
        //Crear una instancia de PHPMailer
    		$mail = new PHPMailer\PHPMailer\PHPMailer();
    		//Definir que vamos a usar SMTP
    		$mail->IsSMTP();
    		//Esto es para activar el modo depuración. En entorno de pruebas lo mejor es 2, en producción siempre 0
    		// 0 = off (producción)
    		// 1 = client messages
    		// 2 = client and server messages
    		$mail->SMTPDebug  = 0;
    		//Ahora definimos gmail como servidor que aloja nuestro SMTP
    		$mail->Host       = 'mail.worksicap.com';
    		//El puerto será el 587 ya que usamos encriptación TLS
    		$mail->Port  = 465;
    		//Definmos la seguridad como SSL
    		$mail->SMTPSecure = 'ssl';
    		//Tenemos que usar gmail autenticados, así que esto a TRUE
    		$mail->SMTPAuth   = true;
    		//Definimos la cuenta que vamos a usar. Dirección completa de la misma
    		$mail->Username   = "info@worksicap.com";
    		//Introducimos nuestra contraseña de gmail
    		$mail->Password   = "p5IumsJNgE7!][3P4";
    		//Definimos el remitente (dirección y, opcionalmente, nombre)
    		$mail->SetFrom('noreply@worksicap.com', 'Worksicap');
    		//Esta línea es por si queréis enviar copia a alguien (dirección y, opcionalmente, nombre)
    		$mail->AddReplyTo('noreply@worksicap.com','noreply');
    		//Y, ahora sí, definimos el destinatario (dirección y, opcionalmente, nombre)
    		$mail->AddAddress($email, 'Destinatario');
    		//Definimos el tema del email
    		$mail->Subject = 'Nueva candidatura';
    		//Para enviar un correo formateado en HTML lo cargamos con la siguiente función. Si no, puedes meterle directamente una cadena de texto.
    		$mail->Body = 
            '
            <!DOCTYPE html>
    			<html lang="es">
    			<head>
    				<meta charset="UTF-8">
    				<title>Nuevo candidato</title>
    			</head>
    			<body>
    				<h2>Una persona se ha postulado a tu oferta de empleo</h2>
    				<p>------------------------</p>
    				<h4>Haga click en este enlace para ver la oferta de empleo en la que se han registrado y luego poder ver los candidatos: </h4>
    				<h1>
    					<a href="https://worksicap.com/oferta.php?id='.$idOferta.'" target="_blank">Ver Oferta</a> 
    				</h1>
    			</body>
    			</html>
            ';
    		$mail->IsHTML(true);
    		$mail->SMTPOptions = array(
    			'ssl' => array(
    				'verify_peer' => false,
    				'verify_peer_name' => false,
    				'allow_self_signed' => true
    			)
    		);
    		//Enviamos el correo
    		if(!$mail->Send()) {
    		echo "<h2>Error: " . $mail->ErrorInfo . "</h2>";
    		} else {
    		echo "<h2>Enviado!</h2>";
    		}
            header('Location: oferta.php?id='.$idOferta);
        }
    }else{
        ?>
            <div id="register2" class="container" style="padding: 2ex;">
                <h2 style="color: white;">No tienes ningún curriculum subido, tendrás que subir uno antes de poder suscribirte a una oferta de empleo.</h2>
                <a href="https://www.worksicap.com/" style="color: white;">volver al inicio</a>
            </div>
				
        <?php
    }

}