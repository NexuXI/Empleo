<?php

// Iniciar la sesión y la conexión a bd
	require_once 'includes/conexion.php';
	require 'PHPMailer-master/src/Exception.php';
	require 'PHPMailer-master/src/PHPMailer.php';
	require 'PHPMailer-master/src/SMTP.php';

if(isset($_POST["email"])){
    if($_POST['email'] != null && $_POST['email'] != ""){
        $email = $_POST['email'];

        $sql = "SELECT *FROM candidatos where email = '$email';";
        $busqueda = mysqli_query($db, $sql);
        if($busqueda != null){
            while($persona = mysqli_fetch_assoc($busqueda)){
                $id = $persona['id'];
                $hash = $persona['hash'];
            }
        }
		
      	//Crear una instancia de PHPMailer
		$mail = new PHPMailer\PHPMailer\PHPMailer();
		//Definir que vamos a usar SMTP
		$mail->IsSMTP();
		//Esto es para activar el modo depuración. En entorno de pruebas lo mejor es 2, en producción siempre 0
		// 0 = off (producción)
		// 1 = client messages
		// 2 = client and server messages
		$mail->SMTPDebug  = 0;
		//Ahora definimos gmail como servidor que aloja nuestro SMTP
		$mail->Host       = 'mail.worksicap.com';
		//El puerto será el 587 ya que usamos encriptación TLS
		$mail->Port  = 465;
		//Definmos la seguridad como SSL
		$mail->SMTPSecure = 'ssl';
		//Tenemos que usar gmail autenticados, así que esto a TRUE
		$mail->SMTPAuth   = true;
		//Definimos la cuenta que vamos a usar. Dirección completa de la misma
		$mail->Username   = "info@worksicap.com";
		//Introducimos nuestra contraseña de gmail
		$mail->Password   = "p5IumsJNgE7!][3P4";
		//Definimos el remitente (dirección y, opcionalmente, nombre)
		$mail->SetFrom('noreply@worksicap.com', 'Worksicap');
		//Esta línea es por si queréis enviar copia a alguien (dirección y, opcionalmente, nombre)
		$mail->AddReplyTo('noreply@worksicap.com','noreply');
		//Y, ahora sí, definimos el destinatario (dirección y, opcionalmente, nombre)
		$mail->AddAddress($email, 'Destinatario');
		//Definimos el tema del email
		$mail->Subject = 'Correo Recuperación';
		//Para enviar un correo formateado en HTML lo cargamos con la siguiente función. Si no, puedes meterle directamente una cadena de texto.
		$mail->Body = 
        '
        <!DOCTYPE html>
			<html lang="es">
			<head>
				<meta charset="UTF-8">
				<title>Verificación</title>
			</head>
			<body>
				<h2>Cambia la contraseña de tu cuenta.</h2>
				<h4>Haz click en el siguiente enlace y cambia la contraseña del mail.</h4>	
				<p>------------------------</p>
				<h1>
					<a href="https://worksicap.com/CambiarUser.php?id='.$id.'&hash='.$hash.'" target="_blank">Cambiar clave</a> 
				</h1>
			</body>
			</html>
        ';
		$mail->IsHTML(true);
		$mail->SMTPOptions = array(
			'ssl' => array(
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true
			)
		);
		//Enviamos el correo
		if(!$mail->Send()) {
		echo "Error: " . $mail->ErrorInfo;
		} else {
		echo "Enviado!";
		}
     

        $headers = "From: noreply@itsicap.com\n";
		$headers .= 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	
        
    }
}
header('Location: login.php');
exit();
?>